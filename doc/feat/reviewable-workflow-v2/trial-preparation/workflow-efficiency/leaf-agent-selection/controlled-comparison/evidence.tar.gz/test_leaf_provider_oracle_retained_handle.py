"""Parent-only execution of the frozen provider review examples."""
import csv
import pytest
from ataraxia.bar import Bar
from ataraxia.errors import ProviderError
from ataraxia.provider import BarProvider

HEADER = "timestamp,open,high,low,close,volume\n"

@pytest.mark.parametrize("row,cause", [
    ("1,100", ValueError),
    ("1,100,200,50,150,1,extra", ValueError),
    ("1,bad,200,50,150,1", ValueError),
    ("1,,200,50,150,1", ValueError),
    ("1,1.0e999,200,50,150,1", OverflowError),
    ('1,"100,200,50,150,1', csv.Error),
])
def test_frozen_error_rows(tmp_path, row, cause):
    path = tmp_path / "shard.csv"
    path.write_text(HEADER + row + "\n")
    provider = BarProvider(path)
    with pytest.raises(ProviderError) as err:
        with provider:
            list(provider)
    assert str(path) in str(err.value)
    assert isinstance(err.value.__cause__, cause)
    assert provider._trial_file.closed

@pytest.mark.parametrize("text", [
    "timing,open,high,low,close,volume\n1,2,3,4,5,6\n",
    "1,2,3,4,5,6\n",
    "",
])
def test_frozen_invalid_headers(tmp_path, text):
    path = tmp_path / "shard.csv"
    path.write_text(text)
    provider = BarProvider(path)
    with pytest.raises(ProviderError) as err:
        with provider:
            list(provider)
    assert str(path) in str(err.value)
    assert provider._trial_file.closed

def test_frozen_header_only(tmp_path):
    path = tmp_path / "shard.csv"
    path.write_text(HEADER)
    provider = BarProvider(path)
    with provider:
        assert list(provider) == []
        with pytest.raises(StopIteration):
            next(provider)
    assert provider._trial_file.closed

def test_frozen_valid_values_blanks_order(tmp_path):
    path = tmp_path / "shard.csv"
    path.write_text(HEADER + "\n1,100,200,50,150,1\n\n2,10.25,30.50,10.00,25.75,4321\n\n")
    provider = BarProvider(path)
    with provider:
        assert list(provider) == [Bar(1,100,200,50,150,1), Bar(2,41,122,40,103,4321)]
        with pytest.raises(StopIteration):
            next(provider)
    assert provider._trial_file.closed

def test_frozen_context_and_hash():
    with pytest.raises(ProviderError):
        next(BarProvider("stub"))
    assert hash(BarProvider("same")) == hash(BarProvider("same"))

@pytest.fixture(autouse=True)
def remember_actual_file(monkeypatch):
    original = BarProvider.__enter__
    def enter(provider):
        result = original(provider)
        provider._trial_file = provider.fd
        return result
    monkeypatch.setattr(BarProvider, chr(95)*2 + "enter" + chr(95)*2, enter)
